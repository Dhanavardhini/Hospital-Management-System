import React from "react"
import AddNewDoctorPage from "../pages/AddNewDoctorPage"

export default function AddNewDoctor(){

return(
    <> 
    <AddNewDoctorPage/>
    </>
)

};