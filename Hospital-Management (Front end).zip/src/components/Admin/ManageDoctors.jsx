import React from 'react';
import ManageDoctorPage from '../pages/ManageDoctorPage';

export default function ManageDoctor(){

    return(
        <>
        <ManageDoctorPage/>
        </>
    )
};