import React from 'react';
import AdappointmentPage from '../pages/AdappointmentPage';

export default function Adappointment (){

    return(
        <>
        <AdappointmentPage/>
        </>
    )
};