import React from 'react';
import PatientRecordPage from '../pages/PatientRecordPage';

export default function PatientRecord(){

    return(
        <>
        <PatientRecordPage/>
        </>
    )
};