import React from 'react';
import AdDashboardPage from '../Pages/AdDashboardPage';

export default function AdDashboard(){
    return(
        <>
        <AdDashboardPage/>
        </>
    )
}