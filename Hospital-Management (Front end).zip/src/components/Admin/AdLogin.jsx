import React from 'react';
import { AdLoginPage } from '../Pages/AdLoginPage';

export default function AdLogin(){

    return(
        <>
        <AdLoginPage/>
        </>
    )

}