import React from 'react'
import { LandingPage } from '../pages/LandingPage'

const Landing = () => {
  return (
    <div>
      <LandingPage/>
    </div>
  )
}

export default Landing
