import React from "react";
import { UserLoginPage } from "../UserPage/UserLoginPage";

export default function UserLogin(){

    return(
        <>
        <UserLoginPage/>
        </>
    )
}