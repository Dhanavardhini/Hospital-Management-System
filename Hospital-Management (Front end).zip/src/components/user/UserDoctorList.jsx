import React from 'react'
import UserDoctorListPage from '../UserPage/UserDoctorListPage'

function UserDoctorList() {
  return (
    <div>
      <UserDoctorListPage/>
    </div>
  )
}

export default UserDoctorList
