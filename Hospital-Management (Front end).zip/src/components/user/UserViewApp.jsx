import React from 'react'
import UserViewAppPage from '../UserPage/UserViewAppPage'

function UserViewApp() {
  return (
    <div>
      <UserViewAppPage/>
    </div>
  )
}

export default UserViewApp
