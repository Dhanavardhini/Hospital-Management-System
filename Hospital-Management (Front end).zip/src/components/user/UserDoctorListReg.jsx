import React from 'react'
import UserDoctorListRegPage from '../UserPage/UserDoctorListRegPage'

function UserDoctorListReg() {
  return (
    <div>
      <UserDoctorListRegPage/>
    </div>
  )
}

export default UserDoctorListReg
