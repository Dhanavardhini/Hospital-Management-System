import React from 'react'
import UserRegisterPage from '../UserPage/UserRegisterPage'

function UserRegister() {
  return (
    <div>
      <UserRegisterPage/>
    </div>
  )
}

export default UserRegister
