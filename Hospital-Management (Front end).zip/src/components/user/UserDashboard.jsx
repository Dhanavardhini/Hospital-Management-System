import React from 'react'
import UserDashboardPage from '../UserPage/UserDashboardPage'

function UserDashboard() {
  return (
    <div>
      <UserDashboardPage/>
    </div>
  )
}

export default UserDashboard
