import React from 'react'
import DocHeader from '../doctor/DocHeader'
import DocListPage from './DocListPage'

export default function DocDashboardPage() {
  return (
    <div>
      <DocListPage/>
    </div>
  )
}


