import React from 'react'
import DocDashboardPage from '../DoctorPage/DocDashboardPage'

function DocDashboard() {
  return (
    <div>
      <DocDashboardPage/>
    </div>
  )
}

export default DocDashboard
