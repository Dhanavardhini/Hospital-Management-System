import React from 'react'
import DocListPage from '../DoctorPage/DocListPage'

function DocList() {
  return (
    <div>
      <DocListPage/>
    </div>
  )
}

export default DocList
