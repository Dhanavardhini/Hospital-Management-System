import React from 'react'
import DocLoginPage from '../DoctorPage/DocLoginPage'

export default function DocLogin() {
  return (
    <div>
      <DocLoginPage/>
    </div>
  )
}
